from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import render
from homePageApi.models import *
from sqlalchemy.orm import *
from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import *
from sqlalchemy.orm import sessionmaker
import sqlalchemy, sqlalchemy.orm
from sqlalchemy.dialects.postgresql import array
from django.http import JsonResponse
from datetime import datetime
import collections
from sqlalchemy.pool import NullPool
from sqlalchemy.sql.functions import coalesce
from datetime import datetime, timedelta
from datetime import *
from rom import util
import requests
from django.db import connection
# below are required if need to check any api without auth
from rest_framework.permissions import IsAuthenticated
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes

# database connection function
def postgresconnection(db):
	dialect = 'postgresql'
	driver = 'psycopg2'
	username = 'postgres'
	password = 'secret007'
	server = 'localhost'
	port = '5432'
	database = db
	url=dialect+'+'+driver+'://'+username+':'+password+'@'+server+':'+port+'/'+database
	try:
		engine = create_engine(url)
		Session = sqlalchemy.orm.sessionmaker(bind=engine)
		session = Session()
		return session
	except:
		return ("Could not establish connection")
		
# saves Location and latitude longitude of search made by user
@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
def saveSearchResult(request):
	session = postgresconnection('ankur_db')
	id = request.user.id
	location = request.GET.get('location')
	latlng = request.GET.get('latlng')
	print "MMMMMMMMMMM",id,location,latlng
	queryset = userSearchResult(user_id=id,
				time=str(datetime.now().time()),
				location=str(location),
				coordinates=str(latlng))
	session.add(queryset)
	session.commit()
	session.close()
	x=1
	return Response(x)
		
# fetch all Location and latitude longitude of search made by user

@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
def fetchSearchResult(request):
	session = postgresconnection('ankur_db')
	id = request.user.id
	output=session.query(userSearchResult.location,userSearchResult.coordinates).filter(userSearchResult.user_id==id).all()
	session.close()
	return Response(output)