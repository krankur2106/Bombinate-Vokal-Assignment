from django.conf.urls import url
import views

urlpatterns = (
	url(r'^saveSearchResult/$', views.saveSearchResult,name='saveSearchResult'),
	url(r'^fetchSearchResult/$', views.fetchSearchResult,name='fetchSearchResult'),
)