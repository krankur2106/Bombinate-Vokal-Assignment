app.controller('vokalWebController',function($http,$scope,$compile,NgMap,apiResults) {
	var vm = this;
	vm.placeChanged = function() {
		vm.place = this.getPlace();
		console.log('location', vm.place.formatted_address);
		$scope.searchedLocation=vm.place.formatted_address;
		$scope.latlng=vm.place.geometry.location;
		vm.map.setCenter(vm.place.geometry.location);
		url='saveSearchResult/';
		param = {"location":$scope.searchedLocation,"latlng":$scope.latlng};
		apiResults(url,param).success(function(data){
			console.log("data",data)
		});
	}
	NgMap.getMap().then(function(map) {
		vm.map = map;
	});
	vm.fetchSearch=function(){
		url='fetchSearchResult/';
		param = {};
		apiResults(url,param).success(function(data){
			vm.searchResult=data;
		});
	}
	vm.userLogout =function(){
		$http.get("http://127.0.0.1:8000/authentication/logout/").success(function(data) {
			window.history.go(-window.history.length);
			window.open('/login', '_self');
        });
	}
});
